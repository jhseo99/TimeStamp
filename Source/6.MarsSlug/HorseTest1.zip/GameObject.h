#pragma once

class GameObject
	:public RenderObject
{
public:
	GameObject();
	~GameObject();

public:
	D3DXVECTOR2 vGamePos;

public:
	void SetGamePos(float x, float y) { vGamePos.x = x; vGamePos.y = y; }
};

