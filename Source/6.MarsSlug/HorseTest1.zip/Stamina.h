#pragma once
class Stamina
{
public:
	Stamina();
	~Stamina();

public:
	RenderObject* pStamina[200];
	RenderObject* pCarrot;

public:
	void Init();
	void SetStaminaPos(float x, float y);
};

