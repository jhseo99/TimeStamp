#include "DXUT.h"
#include "GaBase.h"


Horse::Horse()
{
	InitHorse();
}


Horse::~Horse()
{
}

void Horse::InitHorse()
{
	m_enDirection = Direction::LEFT;
	ZeroMemory(&vDirection, sizeof(vDirection));
	fSpeed = 5.0f;
	fStamina = 100.0f;
	fAccel = 0.02f;
}

void Horse::Process()
{
	SetDirectionRect();
	vGamePos.x += vDirection.x * fSpeed;
	vGamePos.y += vDirection.y * fSpeed;
}

void Horse::SetDirectionRect()
{
	switch (m_enDirection)
	{
	case Direction::LEFT:
		m_rtRect.top = 600;
		m_rtRect.bottom = 900;
		break;
	case Direction::RIGHT:
		m_rtRect.top = 1800;
		m_rtRect.bottom = 2100;
		break;
	case Direction::UP:
		m_rtRect.top = 0;
		m_rtRect.bottom = 300;
		break;
	case Direction::DOWN:
		m_rtRect.top = 1200;
		m_rtRect.bottom = 1500;
		break;
	case Direction::LUP:
		m_rtRect.top = 300;
		m_rtRect.bottom = 600;
		break;
	case Direction::RUP:
		m_rtRect.top = 2100;
		m_rtRect.bottom = 2400;
		break;
	case Direction::LDOWN:
		m_rtRect.top = 900;
		m_rtRect.bottom = 1200;
		break;
	case Direction::RDOWN:
		m_rtRect.top = 1500;
		m_rtRect.bottom = 1800;
		break;
	default:
		break;
	}
}

void Horse::SetDirectionVec(D3DXVECTOR2 vec1, D3DXVECTOR2 vec2)
{
	vDirection.x = vec1.x - vec2.x;
	vDirection.y = vec1.y - vec2.y;

	D3DXVec2Normalize(&vDirection, &vDirection);

	vCross.x = -vDirection.y;
	vCross.y = vDirection.x;
}