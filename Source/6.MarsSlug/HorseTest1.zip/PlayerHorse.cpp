#include "DXUT.h"
#include "GaBase.h"


PlayerHorse::PlayerHorse()
{
}


PlayerHorse::~PlayerHorse()
{
}

void PlayerHorse::Process()
{
	KeyProc();
	Horse::Process();
}

void PlayerHorse::KeyProc()
{
	if (GetAsyncKeyState(VK_UP))
	{
		fSpeed += fAccel;
		fStamina -= 0.1f;
	}
	if (GetAsyncKeyState(VK_DOWN))
	{
		fSpeed -= fAccel * 10.0f;
	}
	if (GetAsyncKeyState(VK_LEFT))
	{
		vGamePos.x -= vCross.x * fSpeed / 1.5f;
		vGamePos.y -= vCross.y * fSpeed / 1.5f;
	}
	if (GetAsyncKeyState(VK_RIGHT))
	{
		vGamePos.x += vCross.x * fSpeed / 1.5f;
		vGamePos.y += vCross.y * fSpeed / 1.5f;
	}
}