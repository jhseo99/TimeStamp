#pragma once

namespace GaBase
{
	enum TextureID
	{
		TRACK,
		HORSE_JEJU,
		HORSE_BUSAN,
		HORSE_SEOUL,
		HORSE_KWANGJU,
		UI,
		STAMINA,
	};
}

#include <hash_map>

using namespace stdext;

#include "ObjectManager.h"
#include "SceneManager.h"

#include "RenderObject.h"
#include "GameObject.h"
#include "Horse.h"
#include "PlayerHorse.h"
#include "Map.h"
#include "Stamina.h"
#include "Stage.h"
