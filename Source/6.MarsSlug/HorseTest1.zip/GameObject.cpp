#include "DXUT.h"
#include "GaBase.h"


GameObject::GameObject()
{
	ZeroMemory(&vGamePos, sizeof(vGamePos));
}


GameObject::~GameObject()
{
}
