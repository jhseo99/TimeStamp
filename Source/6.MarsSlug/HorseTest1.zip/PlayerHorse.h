#pragma once
class PlayerHorse
	:public Horse
{
public:
	PlayerHorse();
	~PlayerHorse();

public:
	void Process();
	void KeyProc();
};

