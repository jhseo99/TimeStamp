#pragma once
class Horse
	:public GameObject
{
public:
	Horse();
	~Horse();

	enum Direction{LEFT, RIGHT, UP, DOWN, LUP, RUP, LDOWN, RDOWN};

public:
	Direction m_enDirection;
	D3DXVECTOR2 vDirection;
	D3DXVECTOR2 vCross;

	float fSpeed;
	float fStamina;
	float fAccel;

public:
	void InitHorse();
	void Process();

public:
	void SetDirectionRect();
	void SetDirectionVec(D3DXVECTOR2 vec1, D3DXVECTOR2 vec2);
};

