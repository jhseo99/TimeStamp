#pragma once
class Stage
{
public:
	Stage();
	~Stage();

public:
	Map* pTrack;
	PlayerHorse* pPlayer;

	RenderObject* pUI;
	Stamina* pStaminaGauge;

public:
	void InitStage();
	void Update();
	void Render();

public:
	void InitTrackSection();
	void SetTrackDirection();
};

