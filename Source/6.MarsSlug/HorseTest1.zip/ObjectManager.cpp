#include "DXUT.h"
#include "GaBase.h"

ObjectManager ObjectManager::singleton;

ObjectManager::ObjectManager()
{
}


ObjectManager::~ObjectManager()
{
}

void ObjectManager::Init(LPDIRECT3DDEVICE9 pd3dDevice)
{
	this->pd3dDevice = pd3dDevice;

	CreateTexture(L"texture\\track.png", GaBase::TextureID::TRACK);
	CreateTexture(L"texture\\horseJeju.png", GaBase::TextureID::HORSE_JEJU);
	CreateTexture(L"texture\\horseBusan.png", GaBase::TextureID::HORSE_BUSAN);
	CreateTexture(L"texture\\horseSeoul.png", GaBase::TextureID::HORSE_SEOUL);
	CreateTexture(L"texture\\horseKwangju.png", GaBase::TextureID::HORSE_KWANGJU);
	CreateTexture(L"texture\\ui.png", GaBase::TextureID::UI);
	CreateTexture(L"texture\\stamina.png", GaBase::TextureID::STAMINA);
}

void ObjectManager::CreateTexture(TCHAR* filename, DWORD id)
{
	D3DXCreateTextureFromFileEx(pd3dDevice,
								filename,
								D3DX_DEFAULT, D3DX_DEFAULT,
								1,
								0,
								D3DFMT_A8R8G8B8,
								D3DPOOL_MANAGED,
								D3DX_FILTER_NONE,
								D3DX_FILTER_NONE,
								NULL,
								NULL,
								NULL,
								&m_pTexture);

	m_TextureMap.insert(TEXMAP_PAIR(id, m_pTexture));
}

LPDIRECT3DTEXTURE9 ObjectManager::GetTexture(DWORD id)
{
	TEXMAP_ITER iter;

	iter = m_TextureMap.find(id);

	if (iter == m_TextureMap.end())
	{
		return NULL;
	}

	return iter->second;
}