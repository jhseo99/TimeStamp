#include "DXUT.h"
#include "GaBase.h"


Map::Map()
{
	Init();
}


Map::~Map()
{
}

void Map::Init()
{
	for (int i = 0; i < SECTION_NUM; i++)
	{
		ZeroMemory(&vSection[i], sizeof(vSection[i]));
	}
}

void Map::SetSectionPos(D3DXVECTOR2* vec, float x, float y)
{
	vec->x = x;
	vec->y = y;
}