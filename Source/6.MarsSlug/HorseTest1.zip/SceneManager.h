#pragma once
class SceneManager
{
public:
	SceneManager();
	~SceneManager();

	static SceneManager* Instance() { return &singleton; }

	enum SceneState{INTRO, MENU, STAGE, ENDING};

public:
	static SceneManager singleton;

	SceneState m_enCurrentScene;

public:
	void Init();
	void SetCurrentScene(SceneState scene_) { m_enCurrentScene = scene_; }
};

#define SCENEMANAGER() SceneManager::Instance()

