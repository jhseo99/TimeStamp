#pragma once

#define SECTION_NUM 8

class Map
	:public RenderObject
{
public:
	Map();
	~Map();

public:
	D3DXVECTOR2 vSection[SECTION_NUM];

public:
	void Init();
	void SetSectionPos(D3DXVECTOR2* vec, float x, float y);
};

