#pragma once

typedef hash_map <DWORD, LPDIRECT3DTEXTURE9> TEXMAP;
typedef TEXMAP::iterator TEXMAP_ITER;
typedef pair <DWORD, LPDIRECT3DTEXTURE9> TEXMAP_PAIR;

class ObjectManager
{
public:
	ObjectManager();
	~ObjectManager();

	static ObjectManager* Instance() { return &singleton; }

public:
	static ObjectManager singleton;

	LPDIRECT3DDEVICE9 pd3dDevice;
	LPDIRECT3DTEXTURE9 m_pTexture;
	TEXMAP m_TextureMap;

public:
	void Init(LPDIRECT3DDEVICE9 pd3dDevice);
	void CreateTexture(TCHAR* filename, DWORD id);
	LPDIRECT3DTEXTURE9 GetTexture(DWORD id);
};

#define OBJECTMANAGER() ObjectManager::Instance()