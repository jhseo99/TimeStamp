#include "DXUT.h"
#include "GaBase.h"


RenderObject::RenderObject()
{
	InitRenderObject();
}


RenderObject::~RenderObject()
{
}

void RenderObject::InitRenderObject()
{
	D3DXCreateSprite(OBJECTMANAGER()->pd3dDevice, &m_pSprite);
	m_pTexture = NULL;
	ZeroMemory(&m_rtRect, sizeof(m_rtRect));
	ZeroMemory(&m_vPosition, sizeof(m_vPosition));
	m_d3dColor = D3DCOLOR_COLORVALUE(1.0f, 1.0f, 1.0f, 1.0f);
	D3DXMatrixTranslation(&m_matWorld, 1.0f, 1.0f, 1.0f);
	m_bVisible = false;
}

void RenderObject::SetTexture(DWORD id)
{
	m_pTexture = OBJECTMANAGER()->GetTexture(id);
}

void RenderObject::Render()
{
	m_pSprite->SetTransform(&m_matWorld);

	m_pSprite->Begin(D3DXSPRITE_ALPHABLEND);
	
	if (m_bVisible)
	{
		m_pSprite->Draw(m_pTexture, &m_rtRect, NULL, &m_vPosition, m_d3dColor);
	}

	m_pSprite->End();
}