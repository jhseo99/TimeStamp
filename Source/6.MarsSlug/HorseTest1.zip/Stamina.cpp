#include "DXUT.h"
#include "GaBase.h"


Stamina::Stamina()
{
	Init();
}


Stamina::~Stamina()
{
}

void Stamina::Init()
{
	for (int i = 0; i < 200; i++)
	{
		pStamina[i] = new RenderObject;
		pStamina[i]->SetTexture(GaBase::TextureID::STAMINA);
		pStamina[i]->SetRect(i, i + 1, 18, 32);
		pStamina[i]->SetPosition(0, 0, 0);
		pStamina[i]->SetTranslate(0, 0);
		pStamina[i]->m_bVisible = true;
	}
	pCarrot = new RenderObject;
	pCarrot->SetTexture(GaBase::TextureID::STAMINA);
	pCarrot->SetRect(200, 238, 0, 45);
	pCarrot->SetPosition(0, 0, 0);
	pCarrot->SetTranslate(0, 0);
	pCarrot->m_bVisible = true;
}

void Stamina::SetStaminaPos(float x, float y)
{
	for (int i = 0; i < 200; i++)
	{
		pStamina[i]->SetPosition(x + i, y, 0);
	}
}