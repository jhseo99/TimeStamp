#include "DXUT.h"
#include "GaBase.h"


Stage::Stage()
{
	InitStage();
}


Stage::~Stage()
{
}

void Stage::InitStage()
{
	pTrack = new Map;
	pTrack->SetTexture(GaBase::TextureID::TRACK);
	pTrack->SetRect(0, 12000, 0, 5300);
	pTrack->SetPosition(-7259, -4380, 0);
	pTrack->m_bVisible = true;
	InitTrackSection();

	pPlayer = new PlayerHorse;
	pPlayer->SetTexture(GaBase::TextureID::HORSE_JEJU);
	pPlayer->SetRect(0, 300, 0, 300);
	pPlayer->SetPosition(250, 150, 0);
	pPlayer->SetGamePos(7659, 4717);
	pPlayer->SetTranslate(0, 0);
	pPlayer->m_bVisible = true;

	pUI = new RenderObject;
	pUI->SetTexture(GaBase::TextureID::UI);
	pUI->SetRect(0, 800, 0, 600);
	pUI->SetPosition(0, 0, 0);
	pUI->SetTranslate(0, 0);
	pUI->m_bVisible = true;

	pStaminaGauge = new Stamina;
}

void Stage::Update()
{
	pPlayer->Process();
	SetTrackDirection();

	pStaminaGauge->SetStaminaPos(167, 546);
	if ((int)(200 / 100 * pPlayer->fStamina) - 1 > 0)
	{
		pStaminaGauge->pCarrot->SetPosition(pStaminaGauge->pStamina[(int)(200 / 100 * pPlayer->fStamina) - 1]->m_vPosition.x - 10, 526, 0);
	}

	pTrack->SetTranslate(7659 - pPlayer->vGamePos.x, 4717 - pPlayer->vGamePos.y);
}

void Stage::Render()
{
	pTrack->Render();
	pPlayer->Render();

	pUI->Render();
	for (int i = 0; i < 200 / 100 * pPlayer->fStamina; i++)
	{
		pStaminaGauge->pStamina[i]->Render();
	}
	pStaminaGauge->pCarrot->Render();
}

void Stage::InitTrackSection()
{
	pTrack->SetSectionPos(&pTrack->vSection[0], 2102, 4586);
	pTrack->SetSectionPos(&pTrack->vSection[1], 788, 2887);
	pTrack->SetSectionPos(&pTrack->vSection[2], 788, 2468);
	pTrack->SetSectionPos(&pTrack->vSection[3], 2102, 768);
	pTrack->SetSectionPos(&pTrack->vSection[4], 9913, 768);
	pTrack->SetSectionPos(&pTrack->vSection[5], 11234, 2468);
	pTrack->SetSectionPos(&pTrack->vSection[6], 11234, 2887);
	pTrack->SetSectionPos(&pTrack->vSection[7], 9913, 4586);
}

void Stage::SetTrackDirection()
{
	if (pPlayer->vGamePos.x > pTrack->vSection[0].x)
	{
		pPlayer->m_enDirection = Horse::Direction::LEFT;
		pPlayer->SetDirectionVec(pTrack->vSection[0], pTrack->vSection[7]);
	}
	if (pPlayer->vGamePos.x < pTrack->vSection[0].x &&
		pPlayer->vGamePos.y >= pTrack->vSection[1].y)
	{
		pPlayer->m_enDirection = Horse::Direction::LUP;
		pPlayer->SetDirectionVec(pTrack->vSection[1], pTrack->vSection[0]);
	}
	if (pPlayer->vGamePos.y < pTrack->vSection[1].y &&
		pPlayer->vGamePos.y >= pTrack->vSection[2].y)
	{
		pPlayer->m_enDirection = Horse::Direction::UP;
		pPlayer->SetDirectionVec(pTrack->vSection[2], pTrack->vSection[1]);
	}
	if (pPlayer->vGamePos.y < pTrack->vSection[1].y &&
		pPlayer->vGamePos.y >= pTrack->vSection[2].y)
	{
		pPlayer->m_enDirection = Horse::Direction::UP;
		pPlayer->SetDirectionVec(pTrack->vSection[2], pTrack->vSection[1]);
	}
	if (pPlayer->vGamePos.y < pTrack->vSection[2].y &&
		pPlayer->vGamePos.x <= pTrack->vSection[3].x)
	{
		pPlayer->m_enDirection = Horse::Direction::RUP;
		pPlayer->SetDirectionVec(pTrack->vSection[3], pTrack->vSection[2]);
	}
	if (pPlayer->vGamePos.x >= pTrack->vSection[3].x &&
		pPlayer->vGamePos.x < pTrack->vSection[4].x &&
		pPlayer->vGamePos.y < pTrack->vSection[2].y)
	{
		pPlayer->m_enDirection = Horse::Direction::RIGHT;
		pPlayer->SetDirectionVec(pTrack->vSection[4], pTrack->vSection[3]);
	}
	if(pPlayer->vGamePos.x >= pTrack->vSection[4].x &&
		pPlayer->vGamePos.y < pTrack->vSection[5].y)
	{
		pPlayer->m_enDirection = Horse::Direction::RDOWN;
		pPlayer->SetDirectionVec(pTrack->vSection[5], pTrack->vSection[4]);
	}
	if (pPlayer->vGamePos.x >= pTrack->vSection[4].x &&
		pPlayer->vGamePos.y > pTrack->vSection[5].y &&
		pPlayer->vGamePos.y < pTrack->vSection[6].y)
	{
		pPlayer->m_enDirection = Horse::Direction::DOWN;
		pPlayer->SetDirectionVec(pTrack->vSection[6], pTrack->vSection[5]);
	}
	if (pPlayer->vGamePos.x >= pTrack->vSection[4].x &&
		pPlayer->vGamePos.y > pTrack->vSection[6].y &&
		pPlayer->vGamePos.x > pTrack->vSection[7].x)
	{
		pPlayer->m_enDirection = Horse::Direction::LDOWN;
		pPlayer->SetDirectionVec(pTrack->vSection[7], pTrack->vSection[6]);
	}
	if (pPlayer->vGamePos.x <= pTrack->vSection[7].x &&
		pPlayer->vGamePos.x > pTrack->vSection[0].x &&
		pPlayer->vGamePos.y > pTrack->vSection[6].y)
	{
		pPlayer->m_enDirection = Horse::Direction::LEFT;
		pPlayer->SetDirectionVec(pTrack->vSection[0], pTrack->vSection[7]);
	}
}